import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import time
import random
from torch.utils.data import DataLoader, TensorDataset

random.seed(1234)

# 检查是否有可用的 GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

class SimpleTextCNN(nn.Module):
    def __init__(self, input_channels, num_classes):
        super(SimpleTextCNN, self).__init__()
        # 定义卷积层
        self.conv1 = nn.Conv2d(in_channels=input_channels, out_channels=100, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(in_channels=input_channels, out_channels=100, kernel_size=4, padding=2)
        self.conv3 = nn.Conv2d(in_channels=input_channels, out_channels=100, kernel_size=5, padding=2)

        # 定义池化层
        self.pool = nn.MaxPool2d(kernel_size=2)

        # 计算池化后的输出维度
        self.fc = nn.Linear(100 * 3 * 14 * 14, num_classes)

    def forward(self, x):
        # x 形状: (batch_size, 1, 28, 28)
        x1 = torch.relu(self.conv1(x))
        x2 = torch.relu(self.conv2(x))
        x3 = torch.relu(self.conv3(x))

        # 池化
        x1 = self.pool(x1)
        x2 = self.pool(x2)
        x3 = self.pool(x3)

        # 展开并拼接卷积结果
        x = torch.cat((x1, x2, x3), dim=1)

        # 将特征展平成二维数据
        x = x.view(x.size(0), -1)

        # 全连接层输出
        out = self.fc(x)
        return out

# 定义训练过程
def train(model, train_data, train_labels, epochs=150, learning_rate=0.001):
    criterion = nn.CrossEntropyLoss()  # 分类任务使用交叉熵损失函数
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    dataset = TensorDataset(torch.tensor(train_data, dtype=torch.float32), torch.tensor(train_labels, dtype=torch.long))
    dataloader = DataLoader(dataset, batch_size=64, shuffle=True)

    for epoch in range(epochs):
        model.train()
        for inputs, labels in dataloader:
            # 将数据转移到指定设备
            inputs, labels = inputs.to(device), labels.to(device)

            # 前向传播
            outputs = model(inputs)
            loss = criterion(outputs, labels)

            # 反向传播和优化
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        if (epoch + 1) % 2 == 0:
            print(f'Epoch [{epoch + 1}/{epochs}], Loss: {loss.item():.4f}')

# 测试函数
def test(model, test_data, test_labels):
    model.eval()  # 切换模型到评估模式

    # 使用torch.no_grad() 关闭梯度计算
    with torch.no_grad():
        # 将数据转移到指定设备
        inputs = torch.tensor(test_data, dtype=torch.float32).to(device)
        labels = torch.tensor(test_labels, dtype=torch.long).to(device)

        # 前向传播
        outputs = model(inputs)

        # 获取预测结果
        _, predicted = torch.max(outputs.data, 1)

        # 计算准确率
        total = labels.size(0)
        correct = (predicted == labels).sum().item()

        accuracy = correct / total
        print(f'Test Accuracy: {accuracy * 100:.2f}%')

# 加载训练数据
# train_data = np.load('train_imgs.npy')  # 数据形状应为 (60000, 1, 28, 28)
# train_labels = np.load('train_imgs_label.npy')  # 标签形状应为 (60000,)
# train_data = np.expand_dims(train_data, axis=1)
train_data = np.load('mnist_train_outer_1.npy')  # 数据形状应为 (60000, 1, 28, 28)
train_labels = np.load('整理文件/train_mnist_label.npy')  # 标签形状应为 (60000,)
train_data = np.expand_dims(train_data, axis=1)

# 实例化模型，并将模型转移到设备
model = SimpleTextCNN(input_channels=1, num_classes=10).to(device)

# 开始训练
start = time.time()
train(model, train_data, train_labels)
end = time.time()
print("用时:%.2f秒" % (end - start))

# 加载测试数据
# test_data = np.load('test_imgs.npy')  # 数据形状应为 (10000, 1, 28, 28)
# test_labels = np.load('test_imgs_label.npy')  # 标签形状应为 (10000,)
# test_data = np.expand_dims(test_data, axis=1)
test_data = np.load('mnist_test_outer_1.npy')
test_labels = np.load('整理文件/test_mnist_label.npy')
test_data = np.expand_dims(test_data, axis=1)

# 调用测试函数
test(model, test_data, test_labels)
