import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import time
import random
from torch.utils.data import DataLoader, TensorDataset

random.seed(1234)

# Check if GPU is available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

class SimpleTextCNN(nn.Module):
    def __init__(self, input_channels, num_classes):
        super(SimpleTextCNN, self).__init__()
        # Define convolutional layers
        self.conv1 = nn.Conv2d(in_channels=input_channels, out_channels=100, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(in_channels=input_channels, out_channels=100, kernel_size=4, padding=2)
        self.conv3 = nn.Conv2d(in_channels=input_channels, out_channels=100, kernel_size=5, padding=2)

        # Define pooling layer
        self.pool = nn.MaxPool2d(kernel_size=2)

        # Calculate the output dimension after pooling for 64x64 input image
        self.fc = nn.Linear(100 * 3 * 32 * 32, num_classes)  # 32x32 is the size after pooling

    def forward(self, x):
        # x shape: (batch_size, 1, 64, 64)
        x1 = torch.relu(self.conv1(x))
        x2 = torch.relu(self.conv2(x))
        x3 = torch.relu(self.conv3(x))

        # Pooling
        x1 = self.pool(x1)
        x2 = self.pool(x2)
        x3 = self.pool(x3)

        # Concatenate convolutions results
        x = torch.cat((x1, x2, x3), dim=1)

        # Flatten for fully connected layer
        x = x.view(x.size(0), -1)

        # Fully connected output
        out = self.fc(x)
        return out

# Define training process
def train(model, train_data, train_labels, epochs=50, learning_rate=0.001):
    criterion = nn.CrossEntropyLoss()  # Cross-entropy for classification
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    dataset = TensorDataset(torch.tensor(train_data, dtype=torch.float32), torch.tensor(train_labels, dtype=torch.long))
    dataloader = DataLoader(dataset, batch_size=64, shuffle=True)

    for epoch in range(epochs):
        model.train()
        for inputs, labels in dataloader:
            # Move data to device
            inputs, labels = inputs.to(device), labels.to(device)

            # Forward pass
            outputs = model(inputs)
            loss = criterion(outputs, labels)

            # Backward pass and optimization
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        if (epoch + 1) % 2 == 0:
            print(f'Epoch [{epoch + 1}/{epochs}], Loss: {loss.item():.4f}')

# Testing function
def test(model, test_data, test_labels):
    model.eval()  # Switch model to evaluation mode

    # Create dataset and dataloader for test data
    dataset = TensorDataset(torch.tensor(test_data, dtype=torch.float32), torch.tensor(test_labels, dtype=torch.long))
    dataloader = DataLoader(dataset, batch_size=64, shuffle=False)

    correct = 0
    total = 0

    with torch.no_grad():
        for inputs, labels in dataloader:
            # Move data to device
            inputs, labels = inputs.to(device), labels.to(device)

            # Forward pass
            outputs = model(inputs)

            # Predictions
            _, predicted = torch.max(outputs.data, 1)

            # Calculate accuracy
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

    accuracy = correct / total
    print(f'Test Accuracy: {accuracy * 100:.4f}%')

# Load training data
train_data = np.load('tiny_origin_train.npy')  # Shape should be (60000, 64, 64)
train_labels = np.load('tiny_origin_train_label.npy')  # Shape should be (60000,)
train_data = np.expand_dims(train_data, axis=1)

# Instantiate model with 200 classes and move to device
model = SimpleTextCNN(input_channels=1, num_classes=200).to(device)

# Train model
start = time.time()
train(model, train_data, train_labels)
end = time.time()
print("Training time: %.2f seconds" % (end - start))

# Load testing data
test_data = np.load('tiny_origin_test.npy')  # Shape should be (10000, 64, 64)
test_labels = np.load('tiny_origin_test_label.npy')  # Shape should be (10000,)
test_data = np.expand_dims(test_data, axis=1)

# Test model
test(model, test_data, test_labels)
