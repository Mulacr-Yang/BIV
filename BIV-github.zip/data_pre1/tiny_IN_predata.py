import numpy as np
import torchvision.datasets as datasets
import torchvision.transforms as transforms
import torch.utils.data as data
import torchvision.models
import torch.nn
import torchvision
import torch.nn as nn
import torch.optim as optim
import os

train_dir = 'tiny-imagenet-200/train'
train_dataset = datasets.ImageFolder(train_dir, transform=transforms.ToTensor())
train_loader = data.DataLoader(train_dataset, batch_size=32, shuffle=True)
train_length = len(train_dataset)
test_dir = 'tiny-imagenet-200/test'
test_dataset = datasets.ImageFolder(test_dir, transform=transforms.ToTensor())
# np.save('tiny_in_train.npy', train_dataset)
# x, y = train_dataset
#np.save('tinyin_train.npy', x)
#np.save('tinyin_train_label.npy', y)
#print(train_dataset[0])
# print(train_dataset[0][0])

train_img = np.empty((100000, 64, 64, 3))
train_label = np.empty((100000, 1))
for i in range(len(train_dataset)):
    # 转置图像数据，从 (3, 64, 64) 到 (64, 64, 3)
    train_img[i] = train_dataset[i][0].numpy().transpose(1, 2, 0)
    train_img[i], train_label[i] = train_dataset[i]
np.save('tinyin_train.npy', train_img)
np.save('tinyin_train_label.npy', train_label)


test_img = np.empty((10000, 64, 64, 3))
test_label = np.empty((10000, 1))

for i in range(len(test_dataset)):
    # 转置图像数据，从 (3, 64, 64) 到 (64, 64, 3)
    test_img[i] = test_dataset[i][0].numpy().transpose(1, 2, 0)
    test_label[i] = test_dataset[i][1]

np.save('tinyin_test.npy', test_img)
np.save('tinyin_test_label.npy', test_label)

