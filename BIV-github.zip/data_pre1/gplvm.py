import numpy as np
import torch
import gpytorch
from torchvision import datasets, transforms
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, TensorDataset
import matplotlib.pyplot as plt

# 加载 MNIST 数据集
transform = transforms.Compose([transforms.ToTensor(), transforms.Lambda(lambda x: x.view(-1))])  # 扁平化每个图像
train_dataset = datasets.MNIST(root='./data', train=True, download=True, transform=transform)
test_dataset = datasets.MNIST(root='./data', train=False, download=True, transform=transform)

# 准备训练数据
train_data = torch.stack([sample[0] for sample in train_dataset], dim=0)  # (60000, 784)
train_labels = torch.tensor([sample[1] for sample in train_dataset])

# 数据标准化
scaler = StandardScaler()
train_data_scaled = scaler.fit_transform(train_data.numpy())  # (60000, 784)
train_data_scaled = torch.tensor(train_data_scaled, dtype=torch.float32)


# 定义 GPLVM 模型
class GPLVM(gpytorch.models.ExactGP):
    def __init__(self, train_x, train_y, likelihood):
        super().__init__(train_x, train_y, likelihood)
        self.likelihood = likelihood

        # 假设潜在空间维度为 2
        self.latent_dim = 2
        self.num_data = train_x.size(0)

        # 潜在空间 X 的初始随机点
        self.X = torch.randn(self.num_data, self.latent_dim)

        # 定义内核（使用 RBF 核函数）
        self.kernel = gpytorch.kernels.RBFKernel()

        # 定义潜在空间到输出空间的映射
        self.linear = torch.nn.Linear(self.latent_dim, train_x.size(1))  # 从潜在空间映射到输入空间

    def forward(self, x):
        # 将潜在空间映射到输出空间
        latent_output = self.linear(self.X)  # 将潜在空间映射到观测空间
        return latent_output


# 定义高斯过程的似然函数
likelihood = gpytorch.likelihoods.GaussianLikelihood()

# 初始化 GPLVM 模型
model = GPLVM(train_data_scaled, train_data_scaled, likelihood)

# 使用 Adam 优化器进行训练
optimizer = torch.optim.Adam(model.parameters(), lr=0.1)
mll = gpytorch.mlls.ExactMarginalLogLikelihood(likelihood, model)

# 创建 TensorDataset 和 DataLoader
dataset = TensorDataset(train_data_scaled)
batch_size = 128  # 设置较小的批量大小
data_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# 训练循环
model.train()
likelihood.train()

epochs = 100
for epoch in range(epochs):
    optimizer.zero_grad()
    for batch_idx, (data_batch,) in enumerate(data_loader):

        # 前向传播
        output = model(data_batch[batch_idx])

        # 为了匹配高斯过程的输出，我们需要确保输出是符合高斯分布的
        dist = gpytorch.distributions.MultivariateNormal(output, torch.eye(output.size(0)))
        loss = -mll(dist, data_batch)  # 负对数似然
        loss.backward()
        optimizer.step()

    if epoch % 10 == 0:
        print(f"Epoch {epoch}/{epochs} - Loss: {loss.item()}")

# 训练完成后，获取降维后的潜在变量
model.eval()
likelihood.eval()

with torch.no_grad():
    reduced_data = model.X.numpy()  # 获取潜在空间的表示

# 将降维后的数据保存为 npy 文件
np.save('mnist_reduced_data.npy', reduced_data)
print("降维后的数据已保存至'mnist_reduced_data.npy'")

# 可视化降维后的数据
plt.figure(figsize=(8, 6))
plt.scatter(reduced_data[:, 0], reduced_data[:, 1], c=train_labels.numpy(), cmap='viridis', s=10)
plt.colorbar()
plt.title('GPLVM on MNIST (2D Latent Space)')
plt.show()
