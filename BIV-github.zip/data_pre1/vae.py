import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset


# 定义 VAE 模型
class VAE(nn.Module):
    def __init__(self, input_dim, latent_dim):
        super(VAE, self).__init__()
        # 编码器
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
        )
        self.fc_mu = nn.Linear(64, latent_dim)
        self.fc_logvar = nn.Linear(64, latent_dim)

        # 解码器
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, 256),
            nn.ReLU(),
            nn.Linear(256, 28 * 28),  # 输出为 (batch_size, 784)
            nn.Sigmoid()
        )

    def encode(self, x):
        h = self.encoder(x)
        mu = self.fc_mu(h)
        logvar = self.fc_logvar(h)
        return mu, logvar

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z):
        return self.decoder(z)

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        return self.decode(z), mu, logvar


# 定义损失函数
def loss_function(recon_x, x, mu, logvar):
    recon_x = recon_x.view(-1, 28 * 28)  # 将解码器输出展平为 (128, 784)
    x = x.view(-1, 28 * 28)  # 将输入目标展平为 (128, 784)
    BCE = nn.functional.binary_cross_entropy(recon_x, x, reduction='sum')
    KLD = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    return BCE + KLD


# 数据准备
data = np.load('datasets/MNIST/train_imgs.npy')  # 假设数据保存在 data.npy 文件中，形状为 (50000, 28, 28)
data = data / 255.0
data = torch.tensor(data, dtype=torch.float32)
dataset = TensorDataset(data)
dataloader = DataLoader(dataset, batch_size=128, shuffle=True)

# 模型和优化器
latent_dim = 1  # 一维潜在空间
model = VAE(input_dim=28 * 28, latent_dim=latent_dim)
optimizer = optim.Adam(model.parameters(), lr=1e-3)

# 训练 VAE 模型
epochs = 20
for epoch in range(epochs):
    model.train()
    train_loss = 0
    for batch in dataloader:
        x = batch[0]
        x = x.view(-1, 28 * 28)  # Flatten the input
        optimizer.zero_grad()
        recon_x, mu, logvar = model(x)
        loss = loss_function(recon_x, x, mu, logvar)
        loss.backward()
        train_loss += loss.item()
        optimizer.step()
    print(f'Epoch {epoch + 1}, Loss: {train_loss / len(dataloader.dataset):.4f}')

# 提取降维后的表示
model.eval()
with torch.no_grad():
    latent_representations = []
    for batch in dataloader:
        x = batch[0]
        x = x.view(-1, 28 * 28)  # Flatten the input
        mu, logvar = model.encode(x)
        z = model.reparameterize(mu, logvar)
        latent_representations.append(z.numpy())
    latent_representations = np.concatenate(latent_representations, axis=0)

# 将降维后的数据存储为 .npy 文件
np.save('AAAAAAA.npy', latent_representations)
print("降维结果已保存到 latent_representations.npy 文件中")
