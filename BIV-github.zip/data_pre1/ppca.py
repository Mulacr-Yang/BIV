import numpy as np
import torch
import torch.nn.functional as F

#读取MNIST
# x = np.load('datasets/MNIST/train_imgs.npy')
# y = np.load('datasets/MNIST/test_imgs.npy')
# x_label = np.load('datasets/MNIST/train_label.npy')
# y_label = np.load('datasets/MNIST/test_label.npy')
x = np.load('datasets/cifar-RGB/train_three.npy')
y = np.load('datasets/cifar-RGB/test_three.npy')

class PPCA:
    def __init__(self, latent_dim, max_iter=100, tol=1e-4):
        """
        初始化PPCA模型
        :param latent_dim: 降维到的潜在维度 M
        :param max_iter: 最大迭代次数
        :param tol: 收敛容差
        """
        self.latent_dim = latent_dim
        self.max_iter = max_iter
        self.tol = tol

    def fit(self, X):
        """
        通过EM算法对PPCA模型进行训练
        :param X: 输入数据, shape (n, n)
        """
        n, d = X.shape
        X = torch.tensor(X, dtype=torch.float32)

        # 初始化参数
        W = torch.randn(d, self.latent_dim)  # 投影矩阵
        sigma2 = torch.tensor(1.0, dtype=torch.float32)  # 噪声方差

        mu = torch.mean(X, dim=0)  # 数据的均值向量
        X_centered = X - mu  # 去均值的数据

        for i in range(self.max_iter):
            # E步：计算隐变量的后验均值和协方差
            M = W.T @ W + sigma2 * torch.eye(self.latent_dim)
            M_inv = torch.inverse(M)
            Ez = X_centered @ W @ M_inv  # 计算隐变量的后验均值

            # 在Ezz的对角线加上小数值以防止奇异矩阵
            Ezz = sigma2 * M_inv + Ez.T @ Ez / n
            Ezz += 1e-6 * torch.eye(self.latent_dim)  # 正则化

            # M步：更新W和sigma2
            W_new = X_centered.T @ Ez @ torch.inverse(Ezz)
            sigma2_new = torch.sum((X_centered - Ez @ W_new.T) ** 2) / (n * d)

            # 检查收敛性
            if torch.norm(W_new - W) < self.tol and abs(sigma2_new - sigma2) < self.tol:
                print(f"收敛于第{i + 1}次迭代")
                break

            W, sigma2 = W_new, sigma2_new

        self.W = W
        self.sigma2 = sigma2
        self.mu = mu

    def transform(self, X):
        """
        将数据投影到低维空间
        :param X: 输入数据, shape (n, n)
        :return: 投影到的低维数据
        """
        X = torch.tensor(X, dtype=torch.float32)
        X_centered = X - self.mu
        M = self.W.T @ self.W + self.sigma2 * torch.eye(self.latent_dim)
        M_inv = torch.inverse(M)
        Z = X_centered @ self.W @ M_inv
        return Z.numpy()

    def inverse_transform(self, Z):
        """
        将低维空间的数据还原到原始空间
        :param Z: 低维数据
        :return: 重建后的数据
        """
        Z = torch.tensor(Z, dtype=torch.float32)
        X_reconstructed = Z @ self.W.T + self.mu
        return X_reconstructed.numpy()

# 示例
'''
if __name__ == "__main__":
    list1 = []
    list2 = []
    ppca = PPCA(latent_dim=1, max_iter=200, tol=1e-4)
    for i in range(len(x)):
        ppca.fit(x[i])
        Z = ppca.transform(x[i])
        list1.append(Z)
    for i in range(len(y)):
        ppca.fit(y[i])
        W = ppca.transform(y[i])
        list2.append(W)
    np.save('mnist_train_ppca.npy', list1)
    np.save('mnist_test_ppca.npy', list2)
'''
if __name__ == "__main__":
    ppca = PPCA(latent_dim=1, max_iter=200, tol=1e-4)
    list1 = []
    list2 = []
    for j in range(len(x)):
        result = np.empty((32, 1, 3))
        for i in range(3):
            ppca.fit(x[j, :, :, i])
            Z = ppca.transform(x[j, :, :, i])
            result[:, :, i] = Z
        list1.append(result)
    for j in range(len(y)):
        result = np.empty((32, 1, 3))
        for i in range(3):
            ppca.fit(y[j, :, :, i])
            Z = ppca.transform(y[j, :, :, i])
            result[:, :, i] = Z
        list2.append(result)
    np.save('cifar3_train_ppca.npy', list1)
    np.save('cifar3_test_ppca.npy', list2)
